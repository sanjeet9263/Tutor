import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { insertUserSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/App";
import { GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

// Step 1: Basic Info and Account Schema
const tutorRegisterSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
  agreeTerms: z.boolean().refine((val) => val === true, {
    message: "You must agree to our terms and conditions.",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Step 2: Profile Schema
const tutorProfileSchema = z.object({
  headline: z.string().min(5, {
    message: "Headline must be at least 5 characters.",
  }).max(100, {
    message: "Headline must not exceed 100 characters."
  }),
  bio: z.string().min(50, {
    message: "Bio must be at least 50 characters.",
  }).max(1000, {
    message: "Bio must not exceed 1000 characters."
  }),
  education: z.string().min(5, {
    message: "Education must be at least 5 characters.",
  }),
  hourlyRate: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Hourly rate must be a positive number.",
  }),
  yearsExperience: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 0, {
    message: "Years of experience must be a non-negative number.",
  }),
  subjects: z.array(z.string()).min(1, {
    message: "Select at least one subject.",
  }),
  availability: z.array(z.string()).min(1, {
    message: "Select at least one availability option.",
  }),
});

type TutorRegisterFormValues = z.infer<typeof tutorRegisterSchema>;
type TutorProfileFormValues = z.infer<typeof tutorProfileSchema>;

const availabilityOptions = [
  "Weekday mornings",
  "Weekday afternoons",
  "Weekday evenings",
  "Weekend mornings",
  "Weekend afternoons",
  "Weekend evenings",
];

const TutorRegistration = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { login } = useAuth();
  const [step, setStep] = useState(1);
  const [userId, setUserId] = useState<number | null>(null);

  // Get subjects list for form
  const { data: subjectsList = [] } = useQuery({
    queryKey: ['/api/subjects/list'],
  });

  // Step 1: Account Registration Form
  const accountForm = useForm<TutorRegisterFormValues>({
    resolver: zodResolver(tutorRegisterSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      email: "",
      firstName: "",
      lastName: "",
      role: "tutor",
      phone: "",
      location: "",
      agreeTerms: false,
    },
  });

  // Step 2: Profile Form
  const profileForm = useForm<TutorProfileFormValues>({
    resolver: zodResolver(tutorProfileSchema),
    defaultValues: {
      headline: "",
      bio: "",
      education: "",
      hourlyRate: "",
      yearsExperience: "",
      subjects: [],
      availability: [],
    },
  });

  const onAccountSubmit = async (data: TutorRegisterFormValues) => {
    try {
      const response = await apiRequest("POST", "/api/auth/register", {
        username: data.username,
        password: data.password,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        role: "tutor",
        phone: data.phone,
        location: data.location,
      });
      
      const userData = await response.json();
      setUserId(userData.id);
      
      toast({
        title: "Account created successfully!",
        description: "Now let's set up your tutor profile",
      });
      
      setStep(2);
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Please try again later",
        variant: "destructive",
      });
    }
  };

  const onProfileSubmit = async (data: TutorProfileFormValues) => {
    if (!userId) {
      toast({
        title: "Error",
        description: "User account not found. Please try again.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const response = await apiRequest("POST", "/api/tutors/profile", {
        userId: userId,
        headline: data.headline,
        bio: data.bio,
        education: data.education,
        hourlyRate: parseInt(data.hourlyRate),
        yearsExperience: parseInt(data.yearsExperience),
        subjects: data.subjects,
        availability: data.availability,
      });
      
      const profileData = await response.json();
      
      // Get user data and log in
      const userResponse = await apiRequest("POST", "/api/auth/login", {
        username: accountForm.getValues("username"),
        password: accountForm.getValues("password"),
      });
      
      const userData = await userResponse.json();
      login(userData);
      
      toast({
        title: "Profile created successfully!",
        description: "Your tutor profile is now live.",
      });
      
      setLocation("/");
    } catch (error) {
      console.error("Profile creation error:", error);
      toast({
        title: "Profile creation failed",
        description: error instanceof Error ? error.message : "Please try again later",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-background min-h-screen py-12">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <GraduationCap className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">Become a Tutor</h1>
          <p className="text-gray-600 mt-2">
            Share your knowledge and help students succeed
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="flex items-center">
            <div className={`rounded-full w-10 h-10 flex items-center justify-center ${
              step >= 1 ? "bg-primary text-white" : "bg-gray-200 text-gray-600"
            }`}>
              1
            </div>
            <div className={`h-1 w-20 ${
              step >= 2 ? "bg-primary" : "bg-gray-200"
            }`}></div>
            <div className={`rounded-full w-10 h-10 flex items-center justify-center ${
              step >= 2 ? "bg-primary text-white" : "bg-gray-200 text-gray-600"
            }`}>
              2
            </div>
          </div>
        </div>

        {step === 1 ? (
          <Card>
            <CardHeader>
              <CardTitle>Create Your Account</CardTitle>
              <CardDescription>
                Fill in your details to create your tutor account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...accountForm}>
                <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={accountForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={accountForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john.doe@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={accountForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="johndoe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number (optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="(123) 456-7890" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={accountForm.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="City, State" {...field} />
                        </FormControl>
                        <FormDescription>
                          Enter your city and state to help students find you.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={accountForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={accountForm.control}
                    name="agreeTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the{" "}
                            <a href="#" className="text-primary hover:underline">
                              Terms of Service
                            </a>{" "}
                            and{" "}
                            <a href="#" className="text-primary hover:underline">
                              Privacy Policy
                            </a>
                          </FormLabel>
                          <FormDescription>
                            You must agree to our terms to create an account.
                          </FormDescription>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full" size="lg">
                    Continue to Profile Setup
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Set Up Your Tutor Profile</CardTitle>
              <CardDescription>
                Tell students about yourself, your expertise, and your teaching style
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                  <FormField
                    control={profileForm.control}
                    name="headline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Profile Headline</FormLabel>
                        <FormControl>
                          <Input placeholder="Experienced Math Tutor specializing in Calculus" {...field} />
                        </FormControl>
                        <FormDescription>
                          A short headline that appears on your tutor card.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={profileForm.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Tell students about your teaching experience, methods, and what makes you a great tutor..."
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Provide details about your teaching style, experience, and approach to helping students.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={profileForm.control}
                    name="education"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Education</FormLabel>
                        <FormControl>
                          <Input placeholder="B.S. in Mathematics, University of Example" {...field} />
                        </FormControl>
                        <FormDescription>
                          List your highest degree or relevant educational qualifications.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={profileForm.control}
                      name="hourlyRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hourly Rate ($)</FormLabel>
                          <FormControl>
                            <Input type="number" min="1" placeholder="35" {...field} />
                          </FormControl>
                          <FormDescription>
                            Set your hourly tutoring rate in USD.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="yearsExperience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Years of Experience</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" placeholder="3" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={profileForm.control}
                    name="subjects"
                    render={() => (
                      <FormItem>
                        <FormLabel>Subjects You Teach</FormLabel>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                          {subjectsList.map((subject: string) => (
                            <FormField
                              key={subject}
                              control={profileForm.control}
                              name="subjects"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={subject}
                                    className="flex items-start space-x-2 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(subject)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, subject])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== subject
                                                )
                                              )
                                        }}
                                      />
                                    </FormControl>
                                    <FormLabel className="text-sm font-normal">
                                      {subject}
                                    </FormLabel>
                                  </FormItem>
                                )
                              }}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={profileForm.control}
                    name="availability"
                    render={() => (
                      <FormItem>
                        <FormLabel>Your Availability</FormLabel>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                          {availabilityOptions.map((option) => (
                            <FormField
                              key={option}
                              control={profileForm.control}
                              name="availability"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={option}
                                    className="flex items-start space-x-2 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(option)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, option])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== option
                                                )
                                              )
                                        }}
                                      />
                                    </FormControl>
                                    <FormLabel className="text-sm font-normal">
                                      {option}
                                    </FormLabel>
                                  </FormItem>
                                )
                              }}
                            />
                          ))}
                        </div>
                        <FormDescription>
                          Select all time slots when you're generally available to tutor.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex gap-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => setStep(1)}
                    >
                      Back
                    </Button>
                    <Button type="submit" className="flex-1">
                      Complete Registration
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TutorRegistration;
