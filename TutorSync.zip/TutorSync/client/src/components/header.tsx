import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useAuth } from "@/App";

const Header = () => {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    closeMobileMenu();
  };

  const navLinks = [
    { text: "Home", href: "/" },
    { text: "Find Tutors", href: "/find-tutors" },
    { text: "How It Works", href: "/how-it-works" },
    { text: "Become a Tutor", href: "/register/tutor" },
  ];

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold">
                Tutor<span className="text-secondary">Connect</span>
              </span>
            </Link>
            <nav className="hidden md:flex ml-10 space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`font-medium ${
                    location === link.href
                      ? "text-primary"
                      : "text-foreground hover:text-primary"
                  }`}
                  onClick={closeMobileMenu}
                >
                  {link.text}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <span className="hidden md:inline-block text-foreground">
                  Hi, {user?.firstName}
                </span>
                <Button onClick={handleLogout} variant="outline">
                  Log out
                </Button>
              </>
            ) : (
              <>
                <Link
                  href="/login"
                  className="hidden md:inline-block text-foreground hover:text-primary font-medium"
                >
                  Log in
                </Link>
                <Link href="/register/tutor">
                  <Button>Sign Up</Button>
                </Link>
              </>
            )}
            <button
              className="md:hidden text-foreground"
              aria-label="Menu"
              onClick={toggleMobileMenu}
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-6 py-4 space-y-3 bg-white border-t">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`block font-medium ${
                  location === link.href
                    ? "text-primary"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={closeMobileMenu}
              >
                {link.text}
              </Link>
            ))}
            {!isAuthenticated && (
              <Link
                href="/login"
                className="block text-foreground hover:text-primary font-medium"
                onClick={closeMobileMenu}
              >
                Log in
              </Link>
            )}
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="block text-foreground hover:text-primary font-medium"
              >
                Log out
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
