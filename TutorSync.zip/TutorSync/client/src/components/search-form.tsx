import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Book } from "lucide-react";

interface SearchFormProps {
  compact?: boolean;
  className?: string;
}

const SearchForm = ({ compact, className = "" }: SearchFormProps) => {
  const [, setLocation] = useLocation();
  const [subject, setSubject] = useState<string>("");
  const [locationValue, setLocationValue] = useState<string>("");

  // Get subject list from API
  const { data: subjectsList } = useQuery({
    queryKey: ['/api/subjects/list'],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let queryParams = new URLSearchParams();
    
    if (subject && subject !== 'all') {
      queryParams.append("subject", subject);
    }
    
    if (locationValue) {
      queryParams.append("location", locationValue);
    }
    
    const queryString = queryParams.toString();
    setLocation(`/find-tutors${queryString ? `?${queryString}` : ''}`);
  };

  return (
    <div className={`bg-white p-4 md:p-6 rounded-lg shadow-lg ${className}`}>
      <form 
        className={`${compact ? 'grid grid-cols-1 md:grid-cols-3 gap-4' : 'flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4'}`}
        onSubmit={handleSubmit}
      >
        <div className="flex-1 relative">
          <Book className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Select value={subject} onValueChange={setSubject}>
            <SelectTrigger className={compact ? "" : "pl-9"}>
              <SelectValue placeholder="Select Subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              {Array.isArray(subjectsList) && subjectsList.map((subj: string) => (
                <SelectItem key={subj} value={subj}>
                  {subj}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1 relative">
          <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Enter ZIP or City"
            value={locationValue}
            onChange={(e) => setLocationValue(e.target.value)}
            className={compact ? "" : "pl-9"}
          />
        </div>
        
        <Button type="submit" className="whitespace-nowrap" variant="secondary">
          <Search className="h-4 w-4 mr-2" />
          Find Tutors
        </Button>
      </form>
    </div>
  );
};

export default SearchForm;
