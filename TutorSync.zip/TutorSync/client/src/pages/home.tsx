import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  CheckCircle, 
  ShieldCheck, 
  Home as HomeIcon, 
  Star, 
  Search, 
  MessageSquare, 
  BookOpen,
  GraduationCap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import TutorCard from "@/components/tutor-card";
import SubjectCard from "@/components/subject-card";
import TestimonialCard from "@/components/testimonial-card";
import SearchForm from "@/components/search-form";

const Home = () => {
  // Fetch featured tutors
  const { data: featuredTutors, isLoading: isLoadingTutors } = useQuery({
    queryKey: ['/api/tutors/featured'],
  });

  // Fetch subject counts
  const { data: subjectCounts, isLoading: isLoadingSubjects } = useQuery({
    queryKey: ['/api/subjects'],
  });

  const testimonials = [
    {
      rating: 5,
      comment: "Michael has been tutoring my son in math for 3 months, and we've seen remarkable improvement. His grades went from C's to A's, and he actually enjoys math now!",
      authorName: "Rebecca Thompson",
      studentInfo: "Parent of John, 10th Grade",
      authorImage: "https://randomuser.me/api/portraits/women/65.jpg"
    },
    {
      rating: 5,
      comment: "Sarah is an amazing science tutor who makes complex concepts easy to understand. My daughter was struggling with chemistry, but now she's one of the top students in her class.",
      authorName: "David Rodriguez",
      studentInfo: "Parent of Emma, 11th Grade",
      authorImage: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      rating: 4.5,
      comment: "Jennifer has been teaching my twins Spanish for the past year. They've made incredible progress and actually look forward to their lessons. I highly recommend her!",
      authorName: "Michael Chen",
      studentInfo: "Parent of Lily & Lucas, 6th Grade",
      authorImage: "https://randomuser.me/api/portraits/men/68.jpg"
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary to-blue-600 py-16 md:py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Find the Perfect Home Tutor for Your Child
            </h1>
            <p className="text-lg md:text-xl text-white opacity-90 mb-8">
              Connect with qualified tutors who can provide personalized learning experiences right at your doorstep.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-6">
              <div className="w-full sm:w-3/4">
                <SearchForm />
              </div>
              <div className="w-full sm:w-1/4 flex sm:flex-col justify-center items-stretch">
                <Link href="/register/tutor" className="w-full">
                  <Button className="w-full h-full min-h-[56px] bg-white text-primary hover:bg-white/90 border-2 border-white">
                    <GraduationCap className="h-5 w-5 mr-2" />
                    Become a Tutor
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="mt-6 text-white flex flex-wrap justify-center gap-3">
              <span className="inline-flex items-center px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm">
                <CheckCircle className="h-4 w-4 mr-1" /> Verified Tutors
              </span>
              <span className="inline-flex items-center px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm">
                <ShieldCheck className="h-4 w-4 mr-1" /> Background Checked
              </span>
              <span className="inline-flex items-center px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm">
                <HomeIcon className="h-4 w-4 mr-1" /> In-Home Lessons
              </span>
              <span className="inline-flex items-center px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm">
                <Star className="h-4 w-4 mr-1" /> Rated by Parents
              </span>
            </div>
          </div>
        </div>
        
        {/* Decorative wave */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-12 text-background fill-current">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"></path>
          </svg>
        </div>
      </section>

      {/* Featured Tutors Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">Featured Tutors</h2>
            <Link href="/find-tutors" className="text-primary hover:text-blue-700 font-medium flex items-center">
              View all tutors <span className="ml-1">→</span>
            </Link>
          </div>
          
          {isLoadingTutors ? (
            <div className="text-center py-8">Loading tutors...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.isArray(featuredTutors) && featuredTutors.map((tutor: any) => {
                // Handle the case where user is null by providing default values
                const firstName = tutor.user?.firstName || tutor.firstName || "Tutor";
                const lastName = tutor.user?.lastName || tutor.lastName || `${tutor.id}`;
                
                // Convert hourly rate to monthly rate in rupees (approximation)
                const monthlyRate = Math.round((tutor.hourlyRate || 0) * 20 * 80); // Assuming 20 hours/month and 1 USD = 80 INR
                
                return (
                  <TutorCard
                    key={tutor.id}
                    id={tutor.id}
                    profilePicture={tutor.user?.profilePicture || "https://via.placeholder.com/400x300?text=No+Profile"}
                    firstName={firstName}
                    lastName={lastName}
                    headline={tutor.headline || ""}
                    bio={tutor.bio || ""}
                    subjects={tutor.subjects || []}
                    hourlyRate={monthlyRate}
                    rating={tutor.rating || 0}
                    isTopRated={tutor.isTopRated}
                    isNew={tutor.isNew}
                  />
                );
              })}
            </div>
          )}
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">How TutorConnect Works</h2>
            <p className="text-gray-600 text-lg">Find the perfect tutor for your child in just a few simple steps</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Search className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Search for Tutors</h3>
              <p className="text-gray-600">Browse profiles based on subject, location, and availability to find tutors who match your needs.</p>
            </div>
            
            {/* Step 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Connect & Discuss</h3>
              <p className="text-gray-600">Contact tutors directly to discuss your child's needs, schedules, and arrange a first session.</p>
            </div>
            
            {/* Step 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mb-4">
                <BookOpen className="h-6 w-6 text-accent" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Start Learning</h3>
              <p className="text-gray-600">Begin personalized tutoring sessions at your home and watch your child's confidence and skills grow.</p>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <Link href="/find-tutors">
              <Button size="lg">
                Find Your Tutor Today
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Subjects Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Browse by Subject</h2>
            <p className="text-gray-600 text-lg">Discover expert tutors across a wide range of academic subjects</p>
          </div>
          
          {isLoadingSubjects ? (
            <div className="text-center py-8">Loading subjects...</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {Array.isArray(subjectCounts) && subjectCounts.slice(0, 8).map((subject: any) => (
                <SubjectCard
                  key={subject.subject}
                  subject={subject.subject}
                  count={subject.count}
                />
              ))}
            </div>
          )}
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-16 bg-primary bg-opacity-5">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">What Parents Say</h2>
            <p className="text-gray-600 text-lg">Parents and students love our tutors</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard
                key={index}
                rating={testimonial.rating}
                comment={testimonial.comment}
                authorName={testimonial.authorName}
                studentInfo={testimonial.studentInfo}
                authorImage={testimonial.authorImage}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Find the Perfect Tutor?</h2>
            <p className="text-lg mb-8 text-white text-opacity-90">Join thousands of parents who have found the right tutor for their children.</p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link href="/find-tutors">
                <Button className="w-full sm:w-auto" variant="accent">
                  Find a Tutor Now
                </Button>
              </Link>
              <Link href="/register/tutor">
                <Button className="w-full sm:w-auto" variant="outline2">
                  Become a Tutor
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
