import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for both parents and tutors
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  role: text("role", { enum: ["parent", "tutor"] }).notNull(),
  phone: text("phone"),
  location: text("location"),
  bio: text("bio"),
  profilePicture: text("profile_picture"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Tutor profile with additional information
export const tutorProfiles = pgTable("tutor_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  headline: text("headline").notNull(),
  bio: text("bio").notNull(),
  hourlyRate: integer("hourly_rate").notNull(),
  yearsExperience: integer("years_experience").notNull(),
  education: text("education").notNull(),
  rating: integer("rating").default(0),
  reviewCount: integer("review_count").default(0),
  isTopRated: boolean("is_top_rated").default(false),
  isNew: boolean("is_new").default(true),
  availability: json("availability").notNull().$type<string[]>(),
  subjects: json("subjects").notNull().$type<string[]>(),
});

// Contact messages from parents to tutors
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull().references(() => users.id),
  toUserId: integer("to_user_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  studentName: text("student_name").notNull(),
  studentGrade: text("student_grade").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  read: boolean("read").default(false),
});

// Reviews for tutors
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  tutorProfileId: integer("tutor_profile_id").notNull().references(() => tutorProfiles.id),
  userId: integer("user_id").notNull().references(() => users.id),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  studentName: text("student_name"),
  studentGrade: text("student_grade"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertTutorProfileSchema = createInsertSchema(tutorProfiles).omit({
  id: true,
});

export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  createdAt: true,
  read: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type TutorProfile = typeof tutorProfiles.$inferSelect;
export type InsertTutorProfile = z.infer<typeof insertTutorProfileSchema>;

export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

// Subjects list
export const subjectsList = [
  "Mathematics",
  "Science",
  "English",
  "History",
  "Foreign Languages",
  "Computer Science",
  "Music",
  "Art & Design",
  "Biology",
  "Chemistry",
  "Physics",
  "Algebra",
  "Calculus",
  "Statistics",
  "Grammar",
  "Literature",
  "Essay Writing",
  "Spanish",
  "French",
  "Geography",
];
