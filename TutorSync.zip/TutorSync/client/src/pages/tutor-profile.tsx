import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { 
  Star, 
  MapPin, 
  Clock, 
  GraduationCap, 
  Book, 
  Calendar,
  Award,
  Check
} from "lucide-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContactForm from "@/components/contact-form";
import { useAuth } from "@/App";
import { useToast } from "@/hooks/use-toast";

const TutorProfile = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [showContactForm, setShowContactForm] = useState(false);

  // Fetch tutor profile data
  const { data: tutorData, isLoading, error } = useQuery({
    queryKey: [`/api/tutors/${id}`],
  });

  // Show error toast if fetching fails
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load tutor profile. Please try again later.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Get tutor rating as display value (0-5 scale)
  const getDisplayRating = (rating: number) => {
    return (rating / 10).toFixed(1);
  };

  const handleContactClick = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please login or register to contact tutors",
        variant: "destructive",
      });
      return;
    }
    setShowContactForm(true);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-6 py-16 text-center">
        <div className="text-xl">Loading tutor profile...</div>
      </div>
    );
  }

  if (!tutorData) {
    return (
      <div className="container mx-auto px-6 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Tutor Not Found</h1>
        <p className="mb-8">The tutor profile you're looking for doesn't exist or has been removed.</p>
        <Link href="/find-tutors">
          <Button>Browse All Tutors</Button>
        </Link>
      </div>
    );
  }

  const { profile, user: tutorUser, reviews } = tutorData;

  return (
    <div className="bg-background min-h-screen py-10">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Column - Tutor Info */}
          <div className="lg:w-2/3">
            {/* Tutor Header Section */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <Avatar className="w-24 h-24 rounded-md">
                    <AvatarImage src={tutorUser.profilePicture} alt={`${tutorUser.firstName} ${tutorUser.lastName}`} />
                    <AvatarFallback className="text-2xl">
                      {tutorUser.firstName.charAt(0)}{tutorUser.lastName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                      <h1 className="text-2xl font-bold">
                        {tutorUser.firstName} {tutorUser.lastName}
                      </h1>
                      <div className="flex items-center">
                        <Star className="h-5 w-5 text-accent fill-current" />
                        <span className="ml-1 font-medium text-lg">
                          {getDisplayRating(profile.rating)}
                        </span>
                        <span className="text-gray-500 text-sm ml-1">
                          ({profile.reviewCount} reviews)
                        </span>
                      </div>
                    </div>
                    
                    <h2 className="text-xl text-gray-700 mb-3">{profile.headline}</h2>
                    
                    <div className="flex flex-wrap gap-y-2 gap-x-4 text-gray-600 mb-4">
                      {tutorUser.location && (
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span>{tutorUser.location}</span>
                        </div>
                      )}
                      <div className="flex items-center">
                        <GraduationCap className="h-4 w-4 mr-1" />
                        <span>{profile.yearsExperience} years experience</span>
                      </div>
                      <div className="flex items-center">
                        <Book className="h-4 w-4 mr-1" />
                        <span>{profile.subjects.length} subjects</span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {profile.subjects.map((subject, index) => (
                        <Badge key={index} variant="subject">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex items-center text-xl font-semibold">
                      ₹{Math.round(profile.hourlyRate * 20 * 80)} {/* Conversion to monthly rate in rupees */}
                      <span className="text-gray-500 text-sm font-normal ml-1">/month</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Tabs Section */}
            <Tabs defaultValue="about" className="mb-8">
              <TabsList className="grid grid-cols-3 mb-4">
                <TabsTrigger value="about">About</TabsTrigger>
                <TabsTrigger value="credentials">Credentials</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>
              
              <TabsContent value="about" className="mt-0">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-3">About Me</h3>
                    <p className="text-gray-700 whitespace-pre-line mb-6">{profile.bio}</p>
                    
                    <h3 className="text-lg font-semibold mb-3">Subjects</h3>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {profile.subjects.map((subject, index) => (
                        <Badge key={index} variant="subject">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-3">Availability</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {profile.availability.map((slot, index) => (
                        <div key={index} className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-primary" />
                          <span>{slot}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="credentials" className="mt-0">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-3">Education</h3>
                    <p className="text-gray-700 mb-6">{profile.education}</p>
                    
                    <h3 className="text-lg font-semibold mb-3">Experience</h3>
                    <div className="flex items-center mb-4">
                      <div className="mr-4">
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                          <GraduationCap className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                      <div>
                        <p className="font-medium">{profile.yearsExperience} Years of Teaching Experience</p>
                        <p className="text-gray-600 text-sm">Experienced in tutoring students of all levels</p>
                      </div>
                    </div>
                    
                    {profile.isTopRated && (
                      <div className="flex items-center mb-4">
                        <div className="mr-4">
                          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                            <Award className="h-6 w-6 text-secondary" />
                          </div>
                        </div>
                        <div>
                          <p className="font-medium">Top Rated Tutor</p>
                          <p className="text-gray-600 text-sm">Consistently receives excellent reviews from students</p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="reviews" className="mt-0">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center mb-6">
                      <div className="flex items-center mr-2">
                        <Star className="h-6 w-6 text-accent fill-current" />
                        <span className="ml-1 text-2xl font-bold">{getDisplayRating(profile.rating)}</span>
                      </div>
                      <span className="text-gray-600">({profile.reviewCount} reviews)</span>
                    </div>
                    
                    {reviews && reviews.length > 0 ? (
                      <div className="space-y-6">
                        {reviews.map((review: any, index: number) => (
                          <div key={index} className="pb-6">
                            {index > 0 && <Separator className="mb-6" />}
                            <div className="flex items-center mb-2">
                              <Avatar className="w-10 h-10 mr-3">
                                {review.user && review.user.profilePicture ? (
                                  <AvatarImage src={review.user.profilePicture} alt={`${review.user.firstName}`} />
                                ) : (
                                  <AvatarFallback>
                                    {review.user ? review.user.firstName.charAt(0) : "?"}
                                  </AvatarFallback>
                                )}
                              </Avatar>
                              <div>
                                <p className="font-medium">
                                  {review.user ? `${review.user.firstName} ${review.user.lastName}` : "Anonymous"}
                                </p>
                                <div className="flex items-center">
                                  {Array.from({ length: review.rating }).map((_, i) => (
                                    <Star key={i} className="h-4 w-4 text-accent fill-current" />
                                  ))}
                                </div>
                              </div>
                            </div>
                            <p className="text-gray-700 mb-2">{review.comment}</p>
                            {review.studentName && (
                              <p className="text-sm text-gray-500">
                                Parent of {review.studentName}, {review.studentGrade}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No reviews yet. Be the first to leave a review!
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Right Column - Contact Form */}
          <div className="lg:w-1/3">
            <div className="sticky top-6">
              <Card>
                <CardContent className="p-6">
                  {showContactForm ? (
                    <ContactForm 
                      tutorId={parseInt(id)} 
                      tutorName={`${tutorUser.firstName} ${tutorUser.lastName}`}
                      onClose={() => setShowContactForm(false)}
                    />
                  ) : (
                    <>
                      <h3 className="text-xl font-semibold mb-4">Contact {tutorUser.firstName}</h3>
                      <p className="text-gray-600 mb-6">
                        Get in touch with {tutorUser.firstName} to discuss your tutoring needs and schedule a session.
                      </p>
                      
                      <div className="space-y-4 mb-6">
                        <div className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                          <p className="text-gray-700">Background checked and verified</p>
                        </div>
                        <div className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                          <p className="text-gray-700">Responds within 24 hours</p>
                        </div>
                        <div className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                          <p className="text-gray-700">Provides personalized lesson plans</p>
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full" 
                        size="lg" 
                        onClick={handleContactClick}
                      >
                        Contact {tutorUser.firstName}
                      </Button>
                      
                      {!isAuthenticated && (
                        <p className="text-sm text-gray-500 text-center mt-3">
                          You'll need to{" "}
                          <Link href="/login" className="text-primary hover:underline">
                            login
                          </Link>{" "}
                          to contact tutors
                        </p>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TutorProfile;
