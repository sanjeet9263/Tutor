import { Link } from "wouter";
import {
  Calculator,
  FlaskRound,
  BookOpen,
  Globe,
  History,
  Cpu,
  Music,
  Palette,
} from "lucide-react";

interface SubjectCardProps {
  subject: string;
  count: number;
}

const getSubjectIcon = (subject: string) => {
  switch (subject) {
    case "Mathematics":
      return <Calculator className="h-5 w-5 text-primary" />;
    case "Science":
      return <FlaskRound className="h-5 w-5 text-primary" />;
    case "English":
      return <BookOpen className="h-5 w-5 text-primary" />;
    case "Foreign Languages":
      return <Globe className="h-5 w-5 text-primary" />;
    case "History":
      return <History className="h-5 w-5 text-primary" />;
    case "Computer Science":
      return <Cpu className="h-5 w-5 text-primary" />;
    case "Music":
      return <Music className="h-5 w-5 text-primary" />;
    case "Art & Design":
      return <Palette className="h-5 w-5 text-primary" />;
    default:
      return <BookOpen className="h-5 w-5 text-primary" />;
  }
};

const SubjectCard = ({ subject, count }: SubjectCardProps) => {
  return (
    <Link href={`/find-tutors?subject=${encodeURIComponent(subject)}`}>
      <div className="bg-white rounded-lg shadow-sm p-6 flex flex-col items-center text-center hover:shadow-md transition duration-300">
        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-3">
          {getSubjectIcon(subject)}
        </div>
        <h3 className="font-semibold text-foreground">{subject}</h3>
        <p className="text-sm text-gray-600 mt-1">
          {count} tutor{count !== 1 ? "s" : ""} available
        </p>
      </div>
    </Link>
  );
};

export default SubjectCard;
