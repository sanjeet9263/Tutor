import { Card, CardContent } from "@/components/ui/card";
import { Star, StarHalf } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface TestimonialCardProps {
  rating: number;
  comment: string;
  authorName: string;
  studentInfo: string;
  authorImage?: string;
}

const TestimonialCard = ({
  rating,
  comment,
  authorName,
  studentInfo,
  authorImage,
}: TestimonialCardProps) => {
  // Convert rating from 0-5 scale to array of stars
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  
  const renderStars = () => {
    const stars = [];
    
    // Full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-accent fill-current" />);
    }
    
    // Half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-accent fill-current" />);
    }
    
    return stars;
  };

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <Card className="bg-white rounded-lg shadow-md p-6">
      <CardContent className="p-0">
        <div className="flex items-center text-accent mb-4">
          {renderStars()}
        </div>
        <p className="text-gray-600 mb-4">{comment}</p>
        <div className="flex items-center">
          <Avatar className="w-10 h-10 mr-3">
            <AvatarImage src={authorImage} alt={authorName} />
            <AvatarFallback>{getInitials(authorName)}</AvatarFallback>
          </Avatar>
          <div>
            <h4 className="font-semibold text-foreground">{authorName}</h4>
            <p className="text-sm text-gray-500">{studentInfo}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestimonialCard;
