import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

interface TutorCardProps {
  id: number;
  profilePicture: string;
  firstName: string;
  lastName: string;
  headline: string;
  bio: string;
  subjects: string[];
  hourlyRate: number;
  rating: number;
  isTopRated?: boolean;
  isNew?: boolean;
}

const TutorCard = ({
  id,
  profilePicture,
  firstName,
  lastName,
  headline,
  bio,
  subjects,
  hourlyRate,
  rating,
  isTopRated,
  isNew,
}: TutorCardProps) => {
  // Convert rating from 0-50 scale to 0-5 scale
  const displayRating = (rating / 10).toFixed(1);

  return (
    <Card className="overflow-hidden tutor-card transition-all">
      <div className="relative pb-2/3">
        <img
          src={profilePicture || "https://via.placeholder.com/400x300?text=No+Image"}
          alt={`${firstName} ${lastName}`}
          className="h-48 w-full object-cover"
        />
        {isTopRated && (
          <div className="absolute top-4 right-4 bg-secondary text-white text-xs px-2 py-1 rounded-full">
            Top Rated
          </div>
        )}
        {isNew && (
          <div className="absolute top-4 right-4 bg-accent text-foreground text-xs px-2 py-1 rounded-full">
            New
          </div>
        )}
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-xl font-semibold text-foreground">
              {firstName} {lastName}
            </h3>
            <p className="text-gray-600">{headline}</p>
          </div>
          <div className="flex items-center text-accent">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 font-medium">{displayRating}</span>
          </div>
        </div>
        <p className="text-gray-600 mb-4 line-clamp-2">
          {bio}
        </p>
        <div className="flex flex-wrap gap-2 mb-4">
          {subjects.slice(0, 3).map((subject, index) => (
            <Badge key={index} variant="subject">
              {subject}
            </Badge>
          ))}
          {subjects.length > 3 && (
            <Badge variant="outline">+{subjects.length - 3} more</Badge>
          )}
        </div>
        <div className="flex justify-between items-center">
          <span className="text-foreground font-semibold">
            ₹{hourlyRate}
            <span className="text-gray-500 text-sm font-normal">/month</span>
          </span>
          <Link href={`/tutor/${id}`}>
            <Button>View Profile</Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default TutorCard;
