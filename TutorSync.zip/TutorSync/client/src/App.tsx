import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import FindTutors from "@/pages/find-tutors";
import TutorProfile from "@/pages/tutor-profile";
import TutorRegistration from "@/pages/tutor-registration";
import Login from "@/pages/login";
import HowItWorks from "@/pages/how-it-works";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { useState, createContext, useContext } from "react";

// Auth context
interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  logout: () => {},
  isAuthenticated: false,
});

export const useAuth = () => useContext(AuthContext);

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/find-tutors" component={FindTutors} />
      <Route path="/tutor/:id" component={TutorProfile} />
      <Route path="/register/tutor" component={TutorRegistration} />
      <Route path="/login" component={Login} />
      <Route path="/how-it-works" component={HowItWorks} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem("user");
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const authValues = {
    user,
    login,
    logout,
    isAuthenticated: !!user,
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthContext.Provider value={authValues}>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow">
            <Router />
          </main>
          <Footer />
        </div>
      </AuthContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
