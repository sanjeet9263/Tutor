import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertTutorProfileSchema, 
  insertContactMessageSchema,
  insertReviewSchema,
  subjectsList
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - all prefixed with /api
  
  // Get featured tutors
  app.get("/api/tutors/featured", async (req: Request, res: Response) => {
    try {
      const limit = Number(req.query.limit) || 4;
      const tutors = await storage.getFeaturedTutors(limit);
      
      // Get the user data for each tutor
      const tutorsWithUserData = await Promise.all(
        tutors.map(async (tutor) => {
          const user = await storage.getUser(tutor.userId);
          return {
            ...tutor,
            user: user ? {
              id: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              location: user.location,
              profilePicture: user.profilePicture,
            } : null,
          };
        })
      );
      
      res.json(tutorsWithUserData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured tutors" });
    }
  });
  
  // Search tutors
  app.get("/api/tutors/search", async (req: Request, res: Response) => {
    try {
      const { subject, location } = req.query;
      const tutors = await storage.searchTutorProfiles({
        subject: subject as string | undefined,
        location: location as string | undefined,
      });
      
      // Get the user data for each tutor
      const tutorsWithUserData = await Promise.all(
        tutors.map(async (tutor) => {
          const user = await storage.getUser(tutor.userId);
          return {
            ...tutor,
            user: user ? {
              id: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              location: user.location,
              profilePicture: user.profilePicture,
            } : null,
          };
        })
      );
      
      res.json(tutorsWithUserData);
    } catch (error) {
      res.status(500).json({ message: "Failed to search tutors" });
    }
  });
  
  // Get a specific tutor profile
  app.get("/api/tutors/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid tutor ID" });
      }
      
      const tutorProfile = await storage.getTutorProfile(id);
      if (!tutorProfile) {
        return res.status(404).json({ message: "Tutor profile not found" });
      }
      
      const user = await storage.getUser(tutorProfile.userId);
      if (!user) {
        return res.status(404).json({ message: "Tutor user not found" });
      }
      
      const reviews = await storage.getReviewsForTutor(id);
      
      // Get user details for each review
      const reviewsWithUserData = await Promise.all(
        reviews.map(async (review) => {
          const reviewUser = await storage.getUser(review.userId);
          return {
            ...review,
            user: reviewUser ? {
              firstName: reviewUser.firstName,
              lastName: reviewUser.lastName,
              profilePicture: reviewUser.profilePicture,
            } : null,
          };
        })
      );
      
      res.json({
        profile: tutorProfile,
        user: {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          location: user.location,
          bio: user.bio,
          profilePicture: user.profilePicture,
        },
        reviews: reviewsWithUserData,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tutor profile" });
    }
  });
  
  // Register a new user
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      const user = await storage.createUser(validatedData);
      
      // If it's a tutor, they need to complete their profile
      if (user.role === "tutor") {
        res.status(201).json({
          id: user.id,
          username: user.username,
          role: user.role,
          message: "User created, please complete your tutor profile",
          requiresProfile: true,
        });
      } else {
        res.status(201).json({
          id: user.id,
          username: user.username,
          role: user.role,
          message: "User created successfully",
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to register user" });
    }
  });
  
  // Login
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });
  
  // Create tutor profile
  app.post("/api/tutors/profile", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTutorProfileSchema.parse(req.body);
      
      // Check if user exists and is a tutor
      const user = await storage.getUser(validatedData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.role !== "tutor") {
        return res.status(403).json({ message: "Only tutors can create a profile" });
      }
      
      // Check if profile already exists
      const existingProfile = await storage.getTutorProfileByUserId(user.id);
      if (existingProfile) {
        return res.status(400).json({ message: "Tutor profile already exists" });
      }
      
      const profile = await storage.createTutorProfile(validatedData);
      res.status(201).json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create tutor profile" });
    }
  });
  
  // Update tutor profile
  app.put("/api/tutors/profile/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid profile ID" });
      }
      
      const profile = await storage.getTutorProfile(id);
      if (!profile) {
        return res.status(404).json({ message: "Tutor profile not found" });
      }
      
      // Only update allowed fields
      const allowedFields = ["headline", "bio", "hourlyRate", "yearsExperience", "education", "availability", "subjects"];
      const updateData = Object.fromEntries(
        Object.entries(req.body).filter(([key]) => allowedFields.includes(key))
      );
      
      const updatedProfile = await storage.updateTutorProfile(id, updateData);
      res.json(updatedProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to update tutor profile" });
    }
  });
  
  // Send contact message to tutor
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      
      // Check if users exist
      const fromUser = await storage.getUser(validatedData.fromUserId);
      if (!fromUser) {
        return res.status(404).json({ message: "Sender not found" });
      }
      
      const toUser = await storage.getUser(validatedData.toUserId);
      if (!toUser) {
        return res.status(404).json({ message: "Recipient not found" });
      }
      
      if (toUser.role !== "tutor") {
        return res.status(400).json({ message: "Recipient must be a tutor" });
      }
      
      const message = await storage.createContactMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // Get contact messages for a user
  app.get("/api/contact/:userId", async (req: Request, res: Response) => {
    try {
      const userId = Number(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const messages = await storage.getContactMessagesForUser(userId);
      
      // Get sender details for each message
      const messagesWithSenderData = await Promise.all(
        messages.map(async (message) => {
          const sender = await storage.getUser(message.fromUserId);
          return {
            ...message,
            sender: sender ? {
              firstName: sender.firstName,
              lastName: sender.lastName,
              email: sender.email,
            } : null,
          };
        })
      );
      
      res.json(messagesWithSenderData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // Create a review for a tutor
  app.post("/api/reviews", async (req: Request, res: Response) => {
    try {
      const validatedData = insertReviewSchema.parse(req.body);
      
      // Check if tutor profile exists
      const tutorProfile = await storage.getTutorProfile(validatedData.tutorProfileId);
      if (!tutorProfile) {
        return res.status(404).json({ message: "Tutor profile not found" });
      }
      
      // Check if reviewer exists
      const reviewer = await storage.getUser(validatedData.userId);
      if (!reviewer) {
        return res.status(404).json({ message: "Reviewer not found" });
      }
      
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });
  
  // Get subject counts for browse by subject
  app.get("/api/subjects", async (req: Request, res: Response) => {
    try {
      const subjectCounts = await storage.getSubjectCounts();
      res.json(subjectCounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subject counts" });
    }
  });
  
  // Get subjects list for dropdowns
  app.get("/api/subjects/list", async (req: Request, res: Response) => {
    try {
      res.json(subjectsList);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subjects list" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
