import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Search, 
  MessageSquare, 
  BookOpen, 
  Star, 
  Shield,
  Clock,
  CheckCircle,
  ThumbsUp
} from "lucide-react";

const HowItWorks = () => {
  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="bg-primary py-16 md:py-24 text-white">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">How TutorConnect Works</h1>
          <p className="text-xl max-w-3xl mx-auto text-white text-opacity-90">
            We've made it easy to find, connect with, and learn from qualified tutors in your area.
          </p>
        </div>
      </section>

      {/* Steps Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="grid gap-12">
              {/* Step 1 */}
              <div className="grid md:grid-cols-[1fr,3fr] gap-6 items-center">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center">
                    <Search className="h-10 w-10 text-primary" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center mb-2">
                    <div className="bg-primary text-white text-lg font-bold w-8 h-8 rounded-full flex items-center justify-center mr-3">
                      1
                    </div>
                    <h2 className="text-2xl font-bold">Search for Tutors</h2>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Start by browsing our extensive database of qualified tutors. Use filters to narrow down by subject, location, and price range to find the perfect match for your needs.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Tips for Effective Searching:</h3>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                      <li>Be specific about the subject you need help with</li>
                      <li>Consider tutors' experience levels and specializations</li>
                      <li>Check availability to ensure it matches your schedule</li>
                      <li>Read reviews from other students and parents</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="relative">
                <div className="absolute left-1/2 -translate-x-1/2 h-full w-px bg-gray-200"></div>
              </div>

              {/* Step 2 */}
              <div className="grid md:grid-cols-[1fr,3fr] gap-6 items-center">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center">
                    <MessageSquare className="h-10 w-10 text-secondary" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center mb-2">
                    <div className="bg-secondary text-white text-lg font-bold w-8 h-8 rounded-full flex items-center justify-center mr-3">
                      2
                    </div>
                    <h2 className="text-2xl font-bold">Connect & Discuss</h2>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Once you've found a tutor who seems like a good fit, reach out through our messaging system. Discuss your child's specific needs, learning goals, and any questions you might have about their teaching approach.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">What to Discuss with Potential Tutors:</h3>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                      <li>Your child's current academic level and challenges</li>
                      <li>Specific areas where they need improvement</li>
                      <li>Learning style and any special requirements</li>
                      <li>Scheduling preferences and session frequency</li>
                      <li>Payment terms and cancellation policies</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="relative">
                <div className="absolute left-1/2 -translate-x-1/2 h-full w-px bg-gray-200"></div>
              </div>

              {/* Step 3 */}
              <div className="grid md:grid-cols-[1fr,3fr] gap-6 items-center">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-yellow-100 flex items-center justify-center">
                    <BookOpen className="h-10 w-10 text-accent" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center mb-2">
                    <div className="bg-accent text-foreground text-lg font-bold w-8 h-8 rounded-full flex items-center justify-center mr-3">
                      3
                    </div>
                    <h2 className="text-2xl font-bold">Start Learning</h2>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Begin your personalized tutoring sessions at your home or agreed-upon location. Your tutor will develop a customized learning plan based on your child's needs and learning style.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Making the Most of Tutoring Sessions:</h3>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                      <li>Prepare a quiet, distraction-free learning environment</li>
                      <li>Have relevant materials ready before the session starts</li>
                      <li>Encourage your child to ask questions and engage actively</li>
                      <li>Request regular progress updates from the tutor</li>
                      <li>Provide feedback to help tutors adjust their approach</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">The TutorConnect Advantage</h2>
            <p className="text-gray-600 text-lg">
              Why thousands of parents choose our platform for their children's education
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                    <Shield className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Verified Tutors</h3>
                  <p className="text-gray-600">
                    All tutors undergo thorough background checks and credential verification before joining our platform.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <Star className="h-8 w-8 text-secondary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
                  <p className="text-gray-600">
                    Transparent ratings and reviews help you choose tutors with proven track records of success.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mb-4">
                    <Clock className="h-8 w-8 text-accent" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Flexible Scheduling</h3>
                  <p className="text-gray-600">
                    Find tutors available when you need them, without long-term contracts or rigid scheduling.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <CheckCircle className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Perfect Matching</h3>
                  <p className="text-gray-600">
                    Our comprehensive filters help you find tutors who match your specific educational needs and preferences.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Success Stories</h2>
            <p className="text-gray-600 text-lg">
              Hear from parents and students who have transformed their educational journey with TutorConnect
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col h-full">
                  <div className="flex items-center text-accent mb-4">
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                  </div>
                  <p className="text-gray-600 italic mb-4 flex-grow">
                    "Finding a math tutor for my daughter used to be a challenge until we discovered TutorConnect. Within a week, we found an amazing tutor who not only improved her grades but also boosted her confidence in mathematics."
                  </p>
                  <div className="flex items-center">
                    <div className="mr-3">
                      <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <span className="font-semibold text-gray-600">RT</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold">Rebecca Thompson</h4>
                      <p className="text-sm text-gray-500">Parent of a 10th Grader</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col h-full">
                  <div className="flex items-center text-accent mb-4">
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                    <Star className="fill-current" />
                  </div>
                  <p className="text-gray-600 italic mb-4 flex-grow">
                    "As a working parent, I needed a flexible tutoring solution for my twins. TutorConnect made it simple to find a Spanish tutor who could come to our home on weekends. The results have been incredible!"
                  </p>
                  <div className="flex items-center">
                    <div className="mr-3">
                      <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <span className="font-semibold text-gray-600">MC</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold">Michael Chen</h4>
                      <p className="text-sm text-gray-500">Parent of 6th Grade Twins</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 text-lg">
              Find answers to common questions about how TutorConnect works
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2">How much do tutors typically charge?</h3>
                <p className="text-gray-600">
                  Tutor rates vary based on subject expertise, experience level, and location. On TutorConnect, you can find tutors ranging from $25-$75 per hour, with the average around $40 per hour.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2">Are tutors required to have teaching certifications?</h3>
                <p className="text-gray-600">
                  While many of our tutors have formal teaching certifications, we also accept tutors with subject matter expertise and proven teaching ability. All tutors must pass our verification process, and their qualifications are clearly listed on their profiles.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2">How do I know if a tutor is right for my child?</h3>
                <p className="text-gray-600">
                  We recommend reviewing tutor profiles thoroughly, checking their experience, teaching style, and reviews from other parents. Most tutors are open to an initial consultation to discuss your child's needs before committing to regular sessions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2">Can I change tutors if it's not a good fit?</h3>
                <p className="text-gray-600">
                  Absolutely! There's no obligation to continue with a tutor if you feel they're not the right match. You can search for and contact other tutors at any time through our platform.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl mb-8 text-white text-opacity-90">
              Join thousands of parents who have found the perfect tutor for their children
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/find-tutors">
                <Button size="lg" variant="accent" className="w-full sm:w-auto">
                  Find a Tutor
                </Button>
              </Link>
              <Link href="/register/tutor">
                <Button size="lg" variant="outline2" className="w-full sm:w-auto">
                  Become a Tutor
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HowItWorks;
