import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin 
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-text py-12 text-white">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">TutorConnect</h3>
            <p className="text-white text-opacity-80 mb-4">
              Connecting parents with qualified tutors for personalized home learning experiences.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-white hover:text-accent" 
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-white hover:text-accent" 
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-white hover:text-accent" 
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-white hover:text-accent" 
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">For Parents</h4>
            <ul className="space-y-2 text-white text-opacity-80">
              <li>
                <Link href="/how-it-works" className="hover:text-white">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/find-tutors" className="hover:text-white">
                  Find Tutors
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Pricing & Payments
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Safety Guidelines
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Parent Resources
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">For Tutors</h4>
            <ul className="space-y-2 text-white text-opacity-80">
              <li>
                <Link href="/register/tutor" className="hover:text-white">
                  Become a Tutor
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Tutor Requirements
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Tutor Resources
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Setting Your Rates
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Success Stories
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-white text-opacity-80">
              <li>
                <a href="#" className="hover:text-white">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  FAQs
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  About Us
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white border-opacity-20 mt-8 pt-8 text-center text-white text-opacity-60">
          <p>&copy; {new Date().getFullYear()} TutorConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
