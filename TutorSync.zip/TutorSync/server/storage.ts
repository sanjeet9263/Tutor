import {
  users,
  tutorProfiles,
  contactMessages,
  reviews,
  type User,
  type InsertUser,
  type TutorProfile,
  type InsertTutorProfile,
  type ContactMessage,
  type InsertContactMessage,
  type Review,
  type InsertReview,
  subjectsList,
} from "@shared/schema";

import session from "express-session";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Tutor profile operations
  getTutorProfile(id: number): Promise<TutorProfile | undefined>;
  getTutorProfileByUserId(userId: number): Promise<TutorProfile | undefined>;
  createTutorProfile(profile: InsertTutorProfile): Promise<TutorProfile>;
  updateTutorProfile(id: number, profile: Partial<TutorProfile>): Promise<TutorProfile | undefined>;
  getAllTutorProfiles(): Promise<TutorProfile[]>;
  searchTutorProfiles(params: { subject?: string; location?: string }): Promise<TutorProfile[]>;
  getFeaturedTutors(limit: number): Promise<TutorProfile[]>;
  
  // Contact message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessagesForUser(userId: number): Promise<ContactMessage[]>;
  markContactMessageAsRead(id: number): Promise<ContactMessage | undefined>;
  
  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getReviewsForTutor(tutorProfileId: number): Promise<Review[]>;
  
  // Get subject counts
  getSubjectCounts(): Promise<{ subject: string; count: number }[]>;
}

import MemoryStore from "memorystore";

export class MemStorage implements IStorage {
  sessionStore: session.Store;
  private users: Map<number, User>;
  private tutorProfiles: Map<number, TutorProfile>;
  private contactMessages: Map<number, ContactMessage>;
  private reviews: Map<number, Review>;
  private userIdCounter: number;
  private tutorProfileIdCounter: number;
  private contactMessageIdCounter: number;
  private reviewIdCounter: number;

  constructor() {
    const MemoryStoreFactory = MemoryStore(session);
    this.sessionStore = new MemoryStoreFactory({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    this.users = new Map();
    this.tutorProfiles = new Map();
    this.contactMessages = new Map();
    this.reviews = new Map();
    this.userIdCounter = 1;
    this.tutorProfileIdCounter = 1;
    this.contactMessageIdCounter = 1;
    this.reviewIdCounter = 1;
    this.seedData();
  }

  private seedData() {
    // Add some sample users and tutor profiles
    const tutorUsers = [
      {
        username: "mjohnson",
        password: "password123",
        email: "mjohnson@example.com",
        firstName: "Michael",
        lastName: "Johnson",
        role: "tutor",
        location: "New York, NY",
        bio: "Mathematics expert with 8+ years of teaching experience.",
        profilePicture: "https://randomuser.me/api/portraits/men/32.jpg",
      },
      {
        username: "smartinez",
        password: "password123",
        email: "smartinez@example.com",
        firstName: "Sarah",
        lastName: "Martinez",
        role: "tutor",
        location: "Boston, MA",
        bio: "Science educator with focus on Biology and Chemistry.",
        profilePicture: "https://randomuser.me/api/portraits/women/44.jpg",
      },
      {
        username: "dwilson",
        password: "password123",
        email: "dwilson@example.com",
        firstName: "David",
        lastName: "Wilson",
        role: "tutor",
        location: "Chicago, IL",
        bio: "English graduate with a passion for literature and creative writing.",
        profilePicture: "https://randomuser.me/api/portraits/men/46.jpg",
      },
      {
        username: "jlee",
        password: "password123",
        email: "jlee@example.com",
        firstName: "Jennifer",
        lastName: "Lee",
        role: "tutor",
        location: "San Francisco, CA",
        bio: "Multilingual tutor specializing in Spanish and French.",
        profilePicture: "https://randomuser.me/api/portraits/women/65.jpg",
      },
    ];

    const tutorProfiles = [
      {
        headline: "Mathematics Tutor",
        bio: "Mathematics expert with 8+ years of teaching experience. Specializes in Algebra, Calculus, and Statistics.",
        hourlyRate: 45,
        yearsExperience: 8,
        education: "M.S. in Mathematics, New York University",
        rating: 49,
        reviewCount: 10,
        isTopRated: true,
        isNew: false,
        availability: ["Weekdays after 4pm", "Saturday mornings"],
        subjects: ["Mathematics", "Algebra", "Calculus", "Statistics"],
      },
      {
        headline: "Science Tutor",
        bio: "Science educator with focus on Biology and Chemistry. Makes complex concepts easy to understand.",
        hourlyRate: 40,
        yearsExperience: 5,
        education: "B.S. in Chemistry, MIT",
        rating: 47,
        reviewCount: 8,
        isTopRated: false,
        isNew: false,
        availability: ["Weekdays after 3pm", "Weekends"],
        subjects: ["Science", "Biology", "Chemistry", "Physics"],
      },
      {
        headline: "English & Literature",
        bio: "English graduate with a passion for literature and creative writing. Helps students develop strong communication skills.",
        hourlyRate: 35,
        yearsExperience: 3,
        education: "B.A. in English Literature, University of Chicago",
        rating: 48,
        reviewCount: 6,
        isTopRated: false,
        isNew: true,
        availability: ["Monday-Thursday", "Sunday afternoons"],
        subjects: ["English", "Grammar", "Literature", "Essay Writing"],
      },
      {
        headline: "Foreign Languages",
        bio: "Multilingual tutor specializing in Spanish and French. Creates engaging, conversation-based learning experiences.",
        hourlyRate: 40,
        yearsExperience: 6,
        education: "M.A. in Spanish, UC Berkeley",
        rating: 50,
        reviewCount: 12,
        isTopRated: false,
        isNew: false,
        availability: ["Weekday evenings", "Saturday"],
        subjects: ["Foreign Languages", "Spanish", "French"],
      },
    ];

    // Create users and their profiles
    tutorUsers.forEach((userData, index) => {
      // For non-async usage, we'll create directly
      const id = this.userIdCounter++;
      const createdAt = new Date();
      const user: User = { ...userData, id, createdAt, phone: null };
      this.users.set(id, user);
      
      const profileId = this.tutorProfileIdCounter++;
      const profile: TutorProfile = { 
        ...tutorProfiles[index], 
        id: profileId,
        userId: id,
        user
      };
      this.tutorProfiles.set(profileId, profile);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { ...userData, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Tutor profile operations
  async getTutorProfile(id: number): Promise<TutorProfile | undefined> {
    return this.tutorProfiles.get(id);
  }

  async getTutorProfileByUserId(userId: number): Promise<TutorProfile | undefined> {
    return Array.from(this.tutorProfiles.values()).find(
      (profile) => profile.userId === userId,
    );
  }

  async createTutorProfile(profileData: InsertTutorProfile): Promise<TutorProfile> {
    const id = this.tutorProfileIdCounter++;
    const profile: TutorProfile = { ...profileData, id };
    this.tutorProfiles.set(id, profile);
    return profile;
  }

  async updateTutorProfile(id: number, profileData: Partial<TutorProfile>): Promise<TutorProfile | undefined> {
    const profile = this.tutorProfiles.get(id);
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...profileData };
    this.tutorProfiles.set(id, updatedProfile);
    return updatedProfile;
  }

  async getAllTutorProfiles(): Promise<TutorProfile[]> {
    return Array.from(this.tutorProfiles.values());
  }

  async searchTutorProfiles(params: { subject?: string; location?: string }): Promise<TutorProfile[]> {
    let tutors = Array.from(this.tutorProfiles.values());
    
    if (params.subject) {
      tutors = tutors.filter(tutor => 
        tutor.subjects.includes(params.subject as string)
      );
    }
    
    if (params.location) {
      // Get users to check location
      const tutorIds = tutors.map(tutor => tutor.userId);
      const tutorUsers = Array.from(this.users.values()).filter(
        user => tutorIds.includes(user.id) && user.location?.toLowerCase().includes(params.location?.toLowerCase() || '')
      );
      const filteredUserIds = tutorUsers.map(user => user.id);
      tutors = tutors.filter(tutor => filteredUserIds.includes(tutor.userId));
    }
    
    return tutors;
  }

  async getFeaturedTutors(limit: number): Promise<TutorProfile[]> {
    const tutors = Array.from(this.tutorProfiles.values());
    // Sort by rating and get top N
    return tutors
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  // Contact message operations
  async createContactMessage(messageData: InsertContactMessage): Promise<ContactMessage> {
    const id = this.contactMessageIdCounter++;
    const createdAt = new Date();
    const message: ContactMessage = { ...messageData, id, createdAt, read: false };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessagesForUser(userId: number): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values()).filter(
      message => message.toUserId === userId
    );
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const message = this.contactMessages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, read: true };
    this.contactMessages.set(id, updatedMessage);
    return updatedMessage;
  }

  // Review operations
  async createReview(reviewData: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const createdAt = new Date();
    const review: Review = { ...reviewData, id, createdAt };
    this.reviews.set(id, review);
    
    // Update tutor profile rating
    const tutorProfile = await this.getTutorProfile(reviewData.tutorProfileId);
    if (tutorProfile) {
      const tutorReviews = await this.getReviewsForTutor(tutorProfile.id);
      const reviewCount = tutorReviews.length;
      const totalRating = tutorReviews.reduce((sum, r) => sum + r.rating, 0);
      const averageRating = Math.round((totalRating / reviewCount) * 10);
      
      await this.updateTutorProfile(tutorProfile.id, {
        rating: averageRating,
        reviewCount,
        isTopRated: averageRating >= 45 && reviewCount >= 5
      });
    }
    
    return review;
  }

  async getReviewsForTutor(tutorProfileId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      review => review.tutorProfileId === tutorProfileId
    );
  }

  // Get subject counts
  async getSubjectCounts(): Promise<{ subject: string; count: number }[]> {
    const subjectCounts: Record<string, number> = {};
    
    // Initialize with all available subjects
    subjectsList.forEach(subject => {
      subjectCounts[subject] = 0;
    });
    
    // Count tutors by subject
    Array.from(this.tutorProfiles.values()).forEach(profile => {
      profile.subjects.forEach(subject => {
        if (subjectCounts[subject] !== undefined) {
          subjectCounts[subject] += 1;
        }
      });
    });
    
    // Format to array
    return Object.entries(subjectCounts)
      .map(([subject, count]) => ({ subject, count }))
      .sort((a, b) => b.count - a.count);
  }
}

import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { eq, desc, sql, and, like } from 'drizzle-orm';
import { db } from './db';
import connectPg from 'connect-pg-simple';

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL must be set for database storage");
    }
    
    this.sessionStore = new PostgresSessionStore({ 
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true 
    });
    
    // Initialize the database with sample data if empty
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      // Check if users table is empty
      const userCount = await db.select({ count: sql`count(*)` }).from(users);
      
      if (parseInt(userCount[0].count as any) === 0) {
        console.log("Initializing database with sample data...");
        await this.seedSampleData();
        console.log("Database initialized successfully");
      }
    } catch (error) {
      console.error("Error initializing database:", error);
    }
  }

  private async seedSampleData() {
    // Sample users
    const user1 = await db.insert(users).values({
      username: "mjohnson",
      email: "mjohnson@example.com",
      password: "password123",
      firstName: "Michael",
      lastName: "Johnson",
      role: "tutor",
      location: "New York, NY",
      bio: "Mathematics expert with 8+ years of teaching experience.",
      profilePicture: "https://randomuser.me/api/portraits/men/32.jpg",
    }).returning();

    const user2 = await db.insert(users).values({
      username: "smartinez",
      email: "smartinez@example.com",
      password: "password123",
      firstName: "Sarah",
      lastName: "Martinez",
      role: "tutor",
      location: "Boston, MA",
      bio: "Science educator with focus on Biology and Chemistry.",
      profilePicture: "https://randomuser.me/api/portraits/women/44.jpg",
    }).returning();

    const user3 = await db.insert(users).values({
      username: "dwilson",
      email: "dwilson@example.com",
      password: "password123",
      firstName: "David",
      lastName: "Wilson",
      role: "tutor",
      location: "Chicago, IL",
      bio: "English graduate with a passion for literature and creative writing.",
      profilePicture: "https://randomuser.me/api/portraits/men/46.jpg",
    }).returning();

    const user4 = await db.insert(users).values({
      username: "jlee",
      email: "jlee@example.com",
      password: "password123",
      firstName: "Jennifer",
      lastName: "Lee",
      role: "tutor",
      location: "San Francisco, CA",
      bio: "Multilingual tutor specializing in Spanish and French.",
      profilePicture: "https://randomuser.me/api/portraits/women/65.jpg",
    }).returning();

    // Sample tutor profiles
    await db.insert(tutorProfiles).values({
      userId: user1[0].id,
      headline: "Mathematics Tutor",
      bio: "Mathematics expert with 8+ years of teaching experience. Specializes in Algebra, Calculus, and Statistics.",
      hourlyRate: 45,
      yearsExperience: 8,
      education: "M.S. in Mathematics, New York University",
      rating: 49,
      reviewCount: 10,
      isTopRated: true,
      isNew: false,
      availability: ["Weekdays after 4pm", "Saturday mornings"],
      subjects: ["Mathematics", "Algebra", "Calculus", "Statistics"],
    });

    await db.insert(tutorProfiles).values({
      userId: user2[0].id,
      headline: "Science Tutor",
      bio: "Science educator with focus on Biology and Chemistry. Makes complex concepts easy to understand.",
      hourlyRate: 40,
      yearsExperience: 5,
      education: "B.S. in Chemistry, MIT",
      rating: 47,
      reviewCount: 8,
      isTopRated: false,
      isNew: false,
      availability: ["Weekdays after 3pm", "Weekends"],
      subjects: ["Science", "Biology", "Chemistry", "Physics"],
    });

    await db.insert(tutorProfiles).values({
      userId: user3[0].id,
      headline: "English & Literature",
      bio: "English graduate with a passion for literature and creative writing. Helps students develop strong communication skills.",
      hourlyRate: 35,
      yearsExperience: 3,
      education: "B.A. in English Literature, University of Chicago",
      rating: 48,
      reviewCount: 6,
      isTopRated: false,
      isNew: true,
      availability: ["Monday-Thursday", "Sunday afternoons"],
      subjects: ["English", "Grammar", "Literature", "Essay Writing"],
    });

    await db.insert(tutorProfiles).values({
      userId: user4[0].id,
      headline: "Foreign Languages",
      bio: "Multilingual tutor specializing in Spanish and French. Creates engaging, conversation-based learning experiences.",
      hourlyRate: 40,
      yearsExperience: 6,
      education: "M.A. in Spanish, UC Berkeley",
      rating: 50,
      reviewCount: 12,
      isTopRated: true,
      isNew: false,
      availability: ["Weekday evenings", "Saturday"],
      subjects: ["Foreign Languages", "Spanish", "French"],
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Tutor profile operations
  async getTutorProfile(id: number): Promise<TutorProfile | undefined> {
    const [profile] = await db
      .select()
      .from(tutorProfiles)
      .where(eq(tutorProfiles.id, id));
    
    if (!profile) return undefined;
    
    // Get the user data
    const user = await this.getUser(profile.userId);
    
    return {
      ...profile,
      user
    } as TutorProfile;
  }

  async getTutorProfileByUserId(userId: number): Promise<TutorProfile | undefined> {
    const [profile] = await db
      .select()
      .from(tutorProfiles)
      .where(eq(tutorProfiles.userId, userId));
    
    if (!profile) return undefined;
    
    // Get the user data
    const user = await this.getUser(profile.userId);
    
    return {
      ...profile,
      user
    } as TutorProfile;
  }

  async createTutorProfile(profileData: InsertTutorProfile): Promise<TutorProfile> {
    const [profile] = await db
      .insert(tutorProfiles)
      .values(profileData)
      .returning();
    
    // Get the user data
    const user = await this.getUser(profileData.userId);
    
    return {
      ...profile,
      user
    } as TutorProfile;
  }

  async updateTutorProfile(id: number, profileData: Partial<TutorProfile>): Promise<TutorProfile | undefined> {
    // Remove 'user' property as it's not part of the tutorProfiles table
    const { user, ...dataToUpdate } = profileData as any;
    
    const [updatedProfile] = await db
      .update(tutorProfiles)
      .set(dataToUpdate)
      .where(eq(tutorProfiles.id, id))
      .returning();
    
    if (!updatedProfile) return undefined;
    
    // Get the complete profile with user data
    return this.getTutorProfile(id);
  }

  async getAllTutorProfiles(): Promise<TutorProfile[]> {
    const profiles = await db
      .select()
      .from(tutorProfiles);
    
    // Add user data to each profile
    const profilesWithUsers = await Promise.all(
      profiles.map(async (profile) => {
        const user = await this.getUser(profile.userId);
        return {
          ...profile,
          user
        } as TutorProfile;
      })
    );
    
    return profilesWithUsers;
  }

  async searchTutorProfiles(params: { subject?: string; location?: string }): Promise<TutorProfile[]> {
    let query = db
      .select()
      .from(tutorProfiles);
    
    // Add filters if provided
    const conditions = [];
    
    if (params.subject) {
      // Using LIKE to search within JSON array elements (database-specific)
      conditions.push(sql`${tutorProfiles.subjects}::text ILIKE ${'%' + params.subject + '%'}`);
    }
    
    if (params.location) {
      // This assumes we have location directly in the tutor profile
      // If it's in the user table, we'd need a join
      const users_with_location = db
        .select({ id: users.id })
        .from(users)
        .where(like(users.location || '', `%${params.location}%`));
      
      conditions.push(sql`${tutorProfiles.userId} IN (${users_with_location})`);
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    const profiles = await query;
    
    // Add user data to each profile
    const profilesWithUsers = await Promise.all(
      profiles.map(async (profile) => {
        const user = await this.getUser(profile.userId);
        return {
          ...profile,
          user
        } as TutorProfile;
      })
    );
    
    return profilesWithUsers;
  }

  async getFeaturedTutors(limit: number): Promise<TutorProfile[]> {
    const profiles = await db
      .select()
      .from(tutorProfiles)
      .orderBy(
        desc(tutorProfiles.isTopRated),
        desc(tutorProfiles.rating)
      )
      .limit(limit);
    
    // Add user data to each profile
    const profilesWithUsers = await Promise.all(
      profiles.map(async (profile) => {
        const user = await this.getUser(profile.userId);
        return {
          ...profile,
          user
        } as TutorProfile;
      })
    );
    
    return profilesWithUsers;
  }

  // Contact message operations
  async createContactMessage(messageData: InsertContactMessage): Promise<ContactMessage> {
    const [message] = await db
      .insert(contactMessages)
      .values({ ...messageData, read: false })
      .returning();
    return message;
  }

  async getContactMessagesForUser(userId: number): Promise<ContactMessage[]> {
    return await db
      .select()
      .from(contactMessages)
      .where(eq(contactMessages.toUserId, userId))
      .orderBy(desc(contactMessages.createdAt));
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const [updatedMessage] = await db
      .update(contactMessages)
      .set({ read: true })
      .where(eq(contactMessages.id, id))
      .returning();
    return updatedMessage;
  }

  // Review operations
  async createReview(reviewData: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values(reviewData)
      .returning();
    
    // Update tutor profile rating
    const reviewList = await this.getReviewsForTutor(reviewData.tutorProfileId);
    const reviewCount = reviewList.length;
    const totalRating = reviewList.reduce((sum, r) => sum + r.rating, 0);
    const averageRating = reviewCount > 0 ? Math.round((totalRating / reviewCount) * 10) : 0;
    
    await db
      .update(tutorProfiles)
      .set({
        rating: averageRating,
        reviewCount,
        isTopRated: averageRating >= 45 && reviewCount >= 5
      })
      .where(eq(tutorProfiles.id, reviewData.tutorProfileId));
    
    return review;
  }

  async getReviewsForTutor(tutorProfileId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.tutorProfileId, tutorProfileId))
      .orderBy(desc(reviews.createdAt));
  }

  // Get subject counts
  async getSubjectCounts(): Promise<{ subject: string; count: number }[]> {
    try {
      // Using jsonb_array_elements for JSON array fields
      const result = await db.execute(sql`
        WITH subject_list AS (
          SELECT jsonb_array_elements_text(subjects::jsonb) as subject
          FROM tutor_profiles
        )
        SELECT subject::text, COUNT(*)::int as count
        FROM subject_list
        GROUP BY subject
        ORDER BY count DESC
      `);
      
      return (result.rows || []).map(row => ({
        subject: String(row.subject || ''),
        count: Number(row.count || 0)
      }));
    } catch (error) {
      console.error("Error fetching subject counts:", error);
      // Return some defaults if there's an error
      return subjectsList.map(subject => ({ subject, count: 0 }));
    }
  }
}

// Use the database storage when DATABASE_URL is available, otherwise fallback to memory storage
export const storage = process.env.DATABASE_URL 
  ? new DatabaseStorage() 
  : new MemStorage();
