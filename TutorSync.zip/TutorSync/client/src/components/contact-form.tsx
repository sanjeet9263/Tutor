import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/App";
import { useToast } from "@/hooks/use-toast";
import { insertContactMessageSchema } from "@shared/schema";

const contactFormSchema = z.object({
  subject: z.string().min(3, {
    message: "Subject must be at least 3 characters.",
  }),
  message: z.string().min(20, {
    message: "Message must be at least 20 characters.",
  }),
  studentName: z.string().min(2, {
    message: "Student name must be at least 2 characters.",
  }),
  studentGrade: z.string().min(1, {
    message: "Student grade is required.",
  }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

interface ContactFormProps {
  tutorId: number;
  tutorName: string;
  onClose: () => void;
}

const ContactForm = ({ tutorId, tutorName, onClose }: ContactFormProps) => {
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      subject: "",
      message: "",
      studentName: "",
      studentGrade: "",
    },
  });

  const onSubmit = async (data: ContactFormValues) => {
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to contact tutors",
        variant: "destructive",
      });
      return;
    }

    try {
      const messageData = {
        fromUserId: user.id,
        toUserId: tutorId,
        subject: data.subject,
        message: data.message,
        studentName: data.studentName,
        studentGrade: data.studentGrade,
      };

      await apiRequest("POST", "/api/contact", messageData);
      
      toast({
        title: "Message sent",
        description: `Your message has been sent to ${tutorName}. They will respond shortly.`,
      });
      
      onClose();
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold">Contact {tutorName}</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="subject"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Subject</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Math Tutoring for 8th Grader" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="studentName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Student's Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Student's name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="studentGrade"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Student's Grade/Level</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 8th Grade, High School" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="message"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Message</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Describe what your child needs help with, your scheduling preferences, and any questions you have."
                    className="min-h-[120px]"
                    {...field} 
                  />
                </FormControl>
                <FormDescription>
                  Be specific about your child's needs to help the tutor prepare.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex gap-2">
            <Button variant="outline" type="button" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Send Message
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default ContactForm;
